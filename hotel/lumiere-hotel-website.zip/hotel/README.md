# Lumière Hotel — Website

A complete, elegant hotel website with public pages, a hidden menu page, and a full admin panel.

---

## Project Structure

```
hotel/
├── index.html              ← Homepage
├── css/
│   └── style.css           ← All styles
├── js/
│   ├── main.js             ← Nav, scroll, modals, animations
│   ├── admin.js            ← Admin CRUD logic
│   └── components.js       ← Shared components (reference only)
├── data/
│   └── data.js             ← All hotel content (rooms, menu, info)
├── pages/
│   ├── rooms.html          ← Rooms & Suites listing
│   ├── about.html          ← About Us
│   ├── contact.html        ← Contact + Map + Form
│   └── menu.html           ← 🔒 Hidden menu (direct link / QR only)
└── admin/
    └── index.html          ← Admin panel (login required)
```

---

## Pages

| Page | URL | Notes |
|---|---|---|
| Home | `/index.html` | Hero, featured rooms, highlights |
| Rooms | `/pages/rooms.html` | Full room listing with gallery |
| About | `/pages/about.html` | Story, vision, mission, values |
| Contact | `/pages/contact.html` | Map, contact form |
| Menu | `/pages/menu.html` | **Hidden** — share via QR/direct link only |
| Admin | `/admin/index.html` | Password-protected CRUD panel |

---

## Admin Panel

**URL:** `/admin/index.html`  
**Credentials:** `admin` / `lumiere2024`

### Features:
- **Rooms**: Add, edit, delete rooms. Upload images via URL. Set featured status.
- **Menu**: Add, edit, delete menu items. Assign categories. Create new categories.
- All changes are saved to `localStorage` and reflected on public pages immediately.

---

## Customisation

All hotel content lives in **`data/data.js`**. Edit:
- `HOTEL` — name, tagline, contact info, story, vision, mission, values
- `ROOMS` — all room data, images, pricing
- `MENU` — all categories and menu items

---

## Fonts & Design

- **Display:** Cormorant Garamond (Google Fonts)
- **Body:** Jost (Google Fonts)
- **Palette:** Warm ivory (#f5f0e8), Deep charcoal (#1a1a18), Gold (#b89c6e)
- **Aesthetic:** Refined luxury minimalism

---

## Deployment

This is a static HTML/CSS/JS site. Deploy to any static host:
- **Vercel / Netlify**: Drop the folder, set `index.html` as root
- **GitHub Pages**: Push to a repo, enable Pages
- **Shared hosting**: Upload all files via FTP

> No build step, no dependencies, no server required.

---

## Notes

- The **menu page** (`/pages/menu.html`) is not linked from any navigation. Share only via direct URL or QR code.
- The **admin panel** uses `sessionStorage` for auth (resets on tab close) and `localStorage` for data.
- For production, replace the admin auth with a proper backend authentication system.
