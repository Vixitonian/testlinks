// ═══════════════════════════════════════════
//  SHARED HTML COMPONENTS (injected by JS)
// ═══════════════════════════════════════════

(function () {

  /* ── Navigation ──────────────────────────── */
  function injectNav() {
    const placeholder = document.getElementById('nav-placeholder');
    if (!placeholder) return;
    placeholder.innerHTML = `
      <nav class="nav">
        <a href="../index.html" class="nav-logo">Lumière</a>
        <div class="nav-links">
          <a href="../index.html" class="nav-link">Home</a>
          <a href="rooms.html" class="nav-link">Rooms</a>
          <a href="about.html" class="nav-link">About</a>
          <a href="contact.html" class="nav-link">Contact</a>
        </div>
        <a href="rooms.html" class="nav-book btn">Book a Room</a>
        <button class="nav-hamburger" aria-label="Menu">
          <span></span><span></span><span></span>
        </button>
      </nav>
      <div class="mobile-nav">
        <button class="mobile-nav-close">×</button>
        <a href="../index.html" class="nav-link">Home</a>
        <a href="rooms.html" class="nav-link">Rooms</a>
        <a href="about.html" class="nav-link">About</a>
        <a href="contact.html" class="nav-link">Contact</a>
        <a href="rooms.html" class="nav-link" style="color:var(--gold-lt)">Book a Room</a>
      </div>
    `;
  }

  /* ── Footer ──────────────────────────────── */
  function injectFooter() {
    const placeholder = document.getElementById('footer-placeholder');
    if (!placeholder) return;
    placeholder.innerHTML = `
      <footer class="footer">
        <div class="container">
          <div class="footer-grid">
            <div>
              <div class="footer-logo">Lumière</div>
              <p class="footer-about">A sanctuary of understated elegance in the heart of the city. Every detail considered, every moment unhurried.</p>
            </div>
            <div>
              <div class="footer-heading">Navigate</div>
              <a href="../index.html" class="footer-link">Home</a>
              <a href="rooms.html" class="footer-link">Rooms</a>
              <a href="about.html" class="footer-link">About Us</a>
              <a href="contact.html" class="footer-link">Contact</a>
            </div>
            <div>
              <div class="footer-heading">Stay</div>
              <a href="rooms.html" class="footer-link">Ivory Suite</a>
              <a href="rooms.html" class="footer-link">Noir Room</a>
              <a href="rooms.html" class="footer-link">Garden Loft</a>
              <a href="rooms.html" class="footer-link">The Penthouse</a>
            </div>
            <div>
              <div class="footer-heading">Contact</div>
              <p class="footer-contact-item">12 Rue de la Paix<br>Lagos, Nigeria</p>
              <p class="footer-contact-item">+234 901 234 5678</p>
              <p class="footer-contact-item">hello@lumierehotel.com</p>
            </div>
          </div>
          <div class="footer-bottom">
            <span class="footer-copy" style="color:rgba(245,240,232,0.4);">© 2024 Lumière Hotel. All rights reserved.</span>
            <span class="footer-credits">Crafted with care.</span>
          </div>
        </div>
      </footer>
    `;
  }

  /* ── Booking Modal ───────────────────────── */
  function injectModal() {
    const placeholder = document.getElementById('modal-placeholder');
    if (!placeholder) return;
    placeholder.innerHTML = `
      <div class="modal-overlay">
        <div class="modal">
          <button class="modal-close">×</button>
          <div class="section-label">Reservation</div>
          <h2>Book Your Stay</h2>
          <div class="modal-room-name"></div>
          <form class="booking-form" style="display:flex;flex-direction:column;gap:1rem;">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">First Name</label>
                <input class="form-input" type="text" required placeholder="Adaeze">
              </div>
              <div class="form-group">
                <label class="form-label">Last Name</label>
                <input class="form-input" type="text" required placeholder="Obi">
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input class="form-input" type="email" required placeholder="you@example.com">
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Check-In</label>
                <input class="form-input" type="date" required>
              </div>
              <div class="form-group">
                <label class="form-label">Check-Out</label>
                <input class="form-input" type="date" required>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Guests</label>
              <select class="form-input">
                <option>1 Guest</option><option>2 Guests</option>
                <option>3 Guests</option><option>4+ Guests</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Special Requests</label>
              <textarea class="form-input" style="min-height:80px;resize:none;" placeholder="Anything we should know?"></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:0.5rem;">
              Send Reservation Request
            </button>
          </form>
        </div>
      </div>
    `;
  }

  document.addEventListener('DOMContentLoaded', () => {
    injectNav();
    injectFooter();
    injectModal();
  });

})();
