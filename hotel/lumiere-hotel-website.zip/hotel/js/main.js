// ═══════════════════════════════════════════
//  LUMIÈRE HOTEL — MAIN JAVASCRIPT
// ═══════════════════════════════════════════

(function () {
  'use strict';

  /* ── Helpers ─────────────────────────────── */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);

  /* ── Nav scroll behaviour ─────────────────── */
  function initNav() {
    const nav = $('.nav');
    if (!nav) return;

    function update() {
      nav.classList.toggle('scrolled', window.scrollY > 50);
    }
    on(window, 'scroll', update);
    update();

    // Active link
    const page = location.pathname.split('/').pop() || 'index.html';
    $$('.nav-link').forEach(a => {
      const href = a.getAttribute('href') || '';
      if (href === page || (page === '' && href === 'index.html')) {
        a.classList.add('active');
      }
    });

    // Hamburger
    const ham = $('.nav-hamburger');
    const mobileNav = $('.mobile-nav');
    const mobileClose = $('.mobile-nav-close');

    on(ham, 'click', () => mobileNav && mobileNav.classList.add('open'));
    on(mobileClose, 'click', () => mobileNav && mobileNav.classList.remove('open'));
    $$('.mobile-nav .nav-link').forEach(a => {
      on(a, 'click', () => mobileNav.classList.remove('open'));
    });
  }

  /* ── Fade-in on scroll ────────────────────── */
  function initFadeIn() {
    const els = $$('.fade-in');
    if (!els.length || !('IntersectionObserver' in window)) {
      els.forEach(e => e.classList.add('visible'));
      return;
    }
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.12 });
    els.forEach(e => obs.observe(e));
  }

  /* ── Room card image slider ───────────────── */
  function initRoomCards() {
    $$('.room-card').forEach(card => {
      const imgs = $$('.room-img-wrap img', card);
      const dots = $$('.room-img-dot', card);
      if (imgs.length <= 1) return;

      let cur = 0;
      function goTo(i) {
        imgs[cur].style.display = 'none';
        dots[cur]?.classList.remove('active');
        cur = i;
        imgs[cur].style.display = 'block';
        dots[cur]?.classList.add('active');
      }

      // Hide all but first
      imgs.forEach((img, i) => { if (i > 0) img.style.display = 'none'; });
      dots[0]?.classList.add('active');

      dots.forEach((dot, i) => on(dot, 'click', e => { e.stopPropagation(); goTo(i); }));

      // Auto-advance on hover
      let timer;
      on(card, 'mouseenter', () => {
        timer = setInterval(() => goTo((cur + 1) % imgs.length), 1800);
      });
      on(card, 'mouseleave', () => clearInterval(timer));
    });
  }

  /* ── Room list gallery (rooms page) ──────────*/
  function initRoomListGalleries() {
    $$('.room-list-item').forEach(item => {
      const mainImg = $('.room-list-gallery img', item);
      const thumbs = $$('.room-thumb', item);
      if (!mainImg || !thumbs.length) return;

      thumbs[0]?.classList.add('active');
      thumbs.forEach((thumb, i) => {
        on(thumb, 'click', () => {
          mainImg.src = thumb.src.replace(/w=\d+/, 'w=900');
          thumbs.forEach(t => t.classList.remove('active'));
          thumb.classList.add('active');
        });
      });
    });
  }

  /* ── Booking Modal ───────────────────────── */
  function initBookingModal() {
    const overlay = $('.modal-overlay');
    const modalRoomName = $('.modal-room-name');
    if (!overlay) return;

    function open(roomName) {
      if (modalRoomName) modalRoomName.textContent = roomName || '';
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
    function close() {
      overlay.classList.remove('open');
      document.body.style.overflow = '';
    }

    // Trigger buttons
    $$('.room-book').forEach(btn => {
      on(btn, 'click', () => {
        const name = btn.dataset.room || 'Selected Room';
        open(name);
      });
    });

    on($('.modal-close'), 'click', close);
    on(overlay, 'click', e => { if (e.target === overlay) close(); });
    on(document, 'keydown', e => { if (e.key === 'Escape') close(); });

    // Booking form submit
    const bookForm = $('.booking-form');
    on(bookForm, 'submit', e => {
      e.preventDefault();
      close();
      showToast('Booking request sent! We\'ll confirm shortly.');
      bookForm.reset();
    });
  }

  /* ── Contact Form ────────────────────────── */
  function initContactForm() {
    const form = $('.contact-form-el');
    const success = $('.form-success');
    if (!form) return;

    on(form, 'submit', e => {
      e.preventDefault();
      form.style.display = 'none';
      if (success) success.style.display = 'block';
    });
  }

  /* ── Toast ───────────────────────────────── */
  window.showToast = function (msg, duration = 3500) {
    let toast = $('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), duration);
  };

  /* ── Menu tab navigation ─────────────────── */
  function initMenuTabs() {
    const btns = $$('.menu-nav-btn');
    const cats = $$('.menu-category');
    if (!btns.length) return;

    btns.forEach(btn => {
      on(btn, 'click', () => {
        btns.forEach(b => b.classList.remove('active'));
        cats.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        const target = $('.menu-category[data-cat="' + btn.dataset.cat + '"]');
        if (target) target.classList.add('active');
      });
    });
  }

  /* ── Init ────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', () => {
    initNav();
    initFadeIn();
    initRoomCards();
    initRoomListGalleries();
    initBookingModal();
    initContactForm();
    initMenuTabs();
  });

})();
