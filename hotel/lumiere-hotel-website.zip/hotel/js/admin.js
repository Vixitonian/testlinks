// ═══════════════════════════════════════════
//  LUMIÈRE ADMIN — JAVASCRIPT
// ═══════════════════════════════════════════

(function () {
  'use strict';

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);

  /* ── Storage ─────────────────────────────── */
  function loadRooms() {
    try {
      const saved = localStorage.getItem('lumiere_rooms');
      return saved ? JSON.parse(saved) : JSON.parse(JSON.stringify(ROOMS));
    } catch { return JSON.parse(JSON.stringify(ROOMS)); }
  }
  function saveRooms(rooms) {
    localStorage.setItem('lumiere_rooms', JSON.stringify(rooms));
  }
  function loadMenu() {
    try {
      const saved = localStorage.getItem('lumiere_menu');
      return saved ? JSON.parse(saved) : JSON.parse(JSON.stringify(MENU));
    } catch { return JSON.parse(JSON.stringify(MENU)); }
  }
  function saveMenu(menu) {
    localStorage.setItem('lumiere_menu', JSON.stringify(menu));
  }

  let rooms = [];
  let menu = [];
  let editingRoomId = null;
  let editingMenuId = null;

  /* ── Auth ────────────────────────────────── */
  function checkAuth() {
    const isLoggedIn = sessionStorage.getItem('lumiere_admin');
    const loginScreen = $('.admin-login-screen');
    const adminContent = $('.admin-content');
    if (!loginScreen) return;

    if (isLoggedIn === 'true') {
      loginScreen.style.display = 'none';
      adminContent.style.display = 'block';
    } else {
      loginScreen.style.display = 'flex';
      adminContent.style.display = 'none';
    }
  }

  function initAuth() {
    const loginForm = $('.admin-login-form');
    const logoutBtn = $('.admin-logout');
    const loginError = $('.admin-login-error');

    on(loginForm, 'submit', e => {
      e.preventDefault();
      const user = $('#admin-user').value.trim();
      const pass = $('#admin-pass').value;
      if (user === 'admin' && pass === 'lumiere2024') {
        sessionStorage.setItem('lumiere_admin', 'true');
        checkAuth();
        initApp();
      } else {
        loginError.style.display = 'block';
        loginError.textContent = 'Invalid credentials. Please try again.';
      }
    });

    on(logoutBtn, 'click', () => {
      sessionStorage.removeItem('lumiere_admin');
      checkAuth();
    });
  }

  /* ── Tab navigation ──────────────────────── */
  function initTabs() {
    const tabBtns = $$('.admin-tab-btn');
    const tabs = $$('.admin-tab');

    tabBtns.forEach(btn => {
      on(btn, 'click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        tabs.forEach(t => t.classList.remove('active'));
        btn.classList.add('active');
        const target = $('.admin-tab[data-tab="' + btn.dataset.tab + '"]');
        if (target) target.classList.add('active');
      });
    });
  }

  /* ── Toast ───────────────────────────────── */
  function showToast(msg) {
    let toast = $('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
  }

  /* ══════════════════════════════════════════
     ROOMS MANAGEMENT
  ═════════════════════════════════════════ */
  function renderRoomsTable() {
    const tbody = $('#rooms-tbody');
    if (!tbody) return;

    tbody.innerHTML = rooms.map(r => `
      <tr>
        <td><img class="td-img" src="${r.images[0] || ''}" alt="${r.name}" onerror="this.style.opacity=0.3"></td>
        <td>
          <div style="font-family:var(--ff-serif);font-size:1.05rem;">${r.name}</div>
          <div style="font-size:0.75rem;color:var(--warm-mid);margin-top:0.2rem;">${r.features.slice(0, 3).join(' · ')}</div>
        </td>
        <td class="td-price">${r.currency}${Number(r.price).toLocaleString()}</td>
        <td>
          <span style="font-size:0.7rem;padding:0.25rem 0.6rem;background:${r.featured ? 'var(--gold)' : 'var(--cream)'};color:${r.featured ? 'white' : 'var(--warm-mid)'};">
            ${r.featured ? 'Featured' : 'Standard'}
          </span>
        </td>
        <td class="td-actions">
          <button class="td-btn" onclick="editRoom(${r.id})">Edit</button>
          <button class="td-btn danger" onclick="deleteRoom(${r.id})">Delete</button>
        </td>
      </tr>
    `).join('');
  }

  function openRoomPanel(room = null) {
    const panel = $('.rooms-panel');
    const title = $('.rooms-panel .admin-form-title');
    panel.classList.add('open');
    editingRoomId = room ? room.id : null;
    if (title) title.textContent = room ? 'Edit Room' : 'Add Room';

    $('#room-name').value = room?.name || '';
    $('#room-desc').value = room?.description || '';
    $('#room-price').value = room?.price || '';
    $('#room-features').value = room?.features?.join(', ') || '';
    $('#room-featured').value = room?.featured ? '1' : '0';
    renderImagePreviews(room?.images || []);
    window._roomImages = room?.images ? [...room.images] : [];
  }

  function renderImagePreviews(imgs) {
    const list = $('.img-preview-list');
    if (!list) return;
    list.innerHTML = imgs.map((src, i) => `
      <div class="img-preview">
        <img src="${src}" alt="">
        <button class="img-preview-remove" onclick="removeRoomImage(${i})">×</button>
      </div>
    `).join('');
  }

  window.removeRoomImage = function (i) {
    window._roomImages.splice(i, 1);
    renderImagePreviews(window._roomImages);
  };

  window.editRoom = function (id) {
    const room = rooms.find(r => r.id === id);
    if (room) openRoomPanel(room);
  };

  window.deleteRoom = function (id) {
    if (!confirm('Delete this room? This cannot be undone.')) return;
    rooms = rooms.filter(r => r.id !== id);
    saveRooms(rooms);
    renderRoomsTable();
    showToast('Room deleted.');
  };

  function saveRoomForm() {
    const name = $('#room-name').value.trim();
    const desc = $('#room-desc').value.trim();
    const price = parseInt($('#room-price').value, 10);
    const features = $('#room-features').value.split(',').map(f => f.trim()).filter(Boolean);
    const featured = $('#room-featured').value === '1';
    const imgInput = $('#room-img-url').value.trim();

    if (!name || !desc || isNaN(price)) {
      showToast('Please fill in all required fields.'); return;
    }

    if (imgInput) {
      window._roomImages.push(imgInput);
      $('#room-img-url').value = '';
    }

    if (editingRoomId) {
      const idx = rooms.findIndex(r => r.id === editingRoomId);
      if (idx > -1) {
        rooms[idx] = { ...rooms[idx], name, description: desc, price, features, featured, images: window._roomImages };
      }
    } else {
      const newId = Math.max(0, ...rooms.map(r => r.id)) + 1;
      rooms.push({ id: newId, name, description: desc, price, currency: '₦', features, featured, images: window._roomImages });
    }

    saveRooms(rooms);
    renderRoomsTable();
    $('.rooms-panel').classList.remove('open');
    showToast(editingRoomId ? 'Room updated.' : 'Room added.');
  }

  function initRoomsPanel() {
    on($('#add-room-btn'), 'click', () => openRoomPanel(null));
    on($('.rooms-panel .admin-form-close'), 'click', () => $('.rooms-panel').classList.remove('open'));
    on($('.rooms-panel .admin-btn-cancel'), 'click', () => $('.rooms-panel').classList.remove('open'));
    on($('.rooms-panel .admin-btn-save'), 'click', saveRoomForm);

    // Add image via URL
    on($('#add-img-btn'), 'click', () => {
      const url = $('#room-img-url').value.trim();
      if (!url) { showToast('Please enter an image URL.'); return; }
      window._roomImages = window._roomImages || [];
      window._roomImages.push(url);
      renderImagePreviews(window._roomImages);
      $('#room-img-url').value = '';
    });
  }

  /* ══════════════════════════════════════════
     MENU MANAGEMENT
  ═════════════════════════════════════════ */
  function getAllMenuItems() {
    return menu.flatMap(cat => cat.items.map(item => ({ ...item, category: cat.category })));
  }

  function renderMenuTable() {
    const tbody = $('#menu-tbody');
    if (!tbody) return;
    const items = getAllMenuItems();

    tbody.innerHTML = items.map(item => `
      <tr>
        <td>
          ${item.image
            ? `<img class="td-img" src="${item.image}" alt="${item.name}">`
            : `<div style="width:64px;height:46px;background:var(--cream);display:flex;align-items:center;justify-content:center;font-size:1.2rem;">◈</div>`
          }
        </td>
        <td>
          <div style="font-family:var(--ff-serif);font-size:1.05rem;">${item.name}</div>
          <div style="font-size:0.75rem;color:var(--warm-mid);margin-top:0.2rem;">${item.desc}</div>
        </td>
        <td><span style="font-size:0.7rem;padding:0.25rem 0.6rem;background:var(--cream);color:var(--warm-mid);">${item.category}</span></td>
        <td class="td-price">₦${Number(item.price).toLocaleString()}</td>
        <td class="td-actions">
          <button class="td-btn" onclick="editMenuItem(${item.id})">Edit</button>
          <button class="td-btn danger" onclick="deleteMenuItem(${item.id})">Delete</button>
        </td>
      </tr>
    `).join('');

    // Populate category select in form
    const catSelect = $('#menu-category');
    if (catSelect) {
      catSelect.innerHTML = menu.map(c => `<option value="${c.category}">${c.category}</option>`).join('');
    }
  }

  function openMenuPanel(item = null) {
    const panel = $('.menu-panel');
    const title = $('.menu-panel .admin-form-title');
    panel.classList.add('open');
    editingMenuId = item ? item.id : null;
    if (title) title.textContent = item ? 'Edit Menu Item' : 'Add Menu Item';

    $('#menu-item-name').value = item?.name || '';
    $('#menu-item-desc').value = item?.desc || '';
    $('#menu-item-price').value = item?.price || '';
    $('#menu-item-image').value = item?.image || '';
    if (item) $('#menu-category').value = item.category;
  }

  window.editMenuItem = function (id) {
    const item = getAllMenuItems().find(i => i.id === id);
    if (item) openMenuPanel(item);
  };

  window.deleteMenuItem = function (id) {
    if (!confirm('Delete this menu item?')) return;
    menu = menu.map(cat => ({
      ...cat,
      items: cat.items.filter(i => i.id !== id)
    }));
    saveMenu(menu);
    renderMenuTable();
    showToast('Item deleted.');
  };

  function saveMenuForm() {
    const name = $('#menu-item-name').value.trim();
    const desc = $('#menu-item-desc').value.trim();
    const price = parseInt($('#menu-item-price').value, 10);
    const image = $('#menu-item-image').value.trim();
    const category = $('#menu-category').value;

    if (!name || !desc || isNaN(price)) {
      showToast('Please fill required fields.'); return;
    }

    if (editingMenuId) {
      menu = menu.map(cat => ({
        ...cat,
        items: cat.items.map(i => i.id === editingMenuId
          ? { ...i, name, desc, price, image, category }
          : i
        )
      }));
      // Move to different category if changed
      const srcCat = menu.find(c => c.items.some(i => i.id === editingMenuId));
      if (srcCat && srcCat.category !== category) {
        const item = srcCat.items.find(i => i.id === editingMenuId);
        menu = menu.map(cat => ({
          ...cat,
          items: cat.category === srcCat.category
            ? cat.items.filter(i => i.id !== editingMenuId)
            : cat.category === category
              ? [...cat.items, item]
              : cat.items
        }));
      }
    } else {
      const newId = Math.max(0, ...getAllMenuItems().map(i => i.id)) + 1;
      menu = menu.map(cat => {
        if (cat.category === category) {
          return { ...cat, items: [...cat.items, { id: newId, name, desc, price, image }] };
        }
        return cat;
      });
    }

    saveMenu(menu);
    renderMenuTable();
    $('.menu-panel').classList.remove('open');
    showToast(editingMenuId ? 'Item updated.' : 'Item added.');
  }

  function initMenuPanel() {
    on($('#add-menu-btn'), 'click', () => openMenuPanel(null));
    on($('.menu-panel .admin-form-close'), 'click', () => $('.menu-panel').classList.remove('open'));
    on($('.menu-panel .admin-btn-cancel'), 'click', () => $('.menu-panel').classList.remove('open'));
    on($('.menu-panel .admin-btn-save'), 'click', saveMenuForm);

    // Add category
    on($('#add-category-btn'), 'click', () => {
      const name = $('#new-category').value.trim();
      if (!name) { showToast('Enter a category name.'); return; }
      if (menu.some(c => c.category === name)) { showToast('Category exists.'); return; }
      menu.push({ category: name, items: [] });
      saveMenu(menu);
      renderMenuTable();
      $('#new-category').value = '';
      showToast('Category added.');
    });
  }

  /* ── Init App ────────────────────────────── */
  function initApp() {
    rooms = loadRooms();
    menu = loadMenu();
    initTabs();
    initRoomsPanel();
    initMenuPanel();
    renderRoomsTable();
    renderMenuTable();
  }

  /* ── Boot ────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', () => {
    // Always show login screen first, then checkAuth determines visibility
    const loginScreen = $('.admin-login-screen');
    const adminContent = $('.admin-content');
    if (loginScreen) loginScreen.style.display = 'flex';
    if (adminContent) adminContent.style.display = 'none';

    initAuth();
    checkAuth();

    if (sessionStorage.getItem('lumiere_admin') === 'true') {
      initApp();
    }
  });

})();
