// ═══════════════════════════════════════════
//  HOTEL DATA STORE — edit everything here
// ═══════════════════════════════════════════

const HOTEL = {
  name: "Lumière",
  tagline: "Where light meets luxury.",
  intro: "Nestled in the heart of the city, Lumière is a sanctuary of understated elegance — a place where every detail is considered, every moment unhurried.",
  address: "12 Rue de la Paix, Lagos, Nigeria",
  phone: "+234 901 234 5678",
  email: "hello@lumierehotel.com",
  mapEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.7282839478!2d3.3791770!3d6.4550570!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwMjcnMTguMiJOIDPCsDIyJzQ0LjkiRQ!5e0!3m2!1sen!2sng!4v1234567890",
  story: "Lumière was born from a simple belief: that true luxury is not excess — it is precision. Founded in 2018 by architect-turned-hotelier Adaeze Obi, every room, corridor, and garden was designed with one question in mind: what does a guest truly need to feel at peace?",
  vision: "To redefine hospitality in West Africa — where quiet refinement, cultural authenticity, and modern comfort coexist effortlessly.",
  mission: "To provide each guest with a deeply personal experience rooted in warmth, attention, and beauty — without pretence.",
  values: [
    { icon: "◈", title: "Simplicity", desc: "We remove what doesn't belong." },
    { icon: "◉", title: "Warmth", desc: "Every guest is a welcomed friend." },
    { icon: "◇", title: "Craft", desc: "Details are never an afterthought." },
    { icon: "○", title: "Authenticity", desc: "We are genuinely, proudly ourselves." }
  ]
};

const ROOMS = [
  {
    id: 1,
    name: "Ivory Suite",
    description: "A serene retreat wrapped in soft linen and warm light. The Ivory Suite offers a king bed, a deep soaking tub, and a private balcony overlooking the garden.",
    price: 85000,
    currency: "₦",
    features: ["King Bed", "Private Balcony", "Soaking Tub", "City View", "Free Wi-Fi", "Room Service"],
    images: [
      "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800&q=80",
      "https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=800&q=80",
      "https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?w=800&q=80"
    ],
    featured: true
  },
  {
    id: 2,
    name: "Noir Room",
    description: "Dark timbers, matte stone, and a ceiling of stars. The Noir Room is designed for those who find beauty in shadow — intimate, focused, and deeply restful.",
    price: 55000,
    currency: "₦",
    features: ["Queen Bed", "Rainfall Shower", "Smart TV", "Blackout Curtains", "Free Wi-Fi", "Minibar"],
    images: [
      "https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800&q=80",
      "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800&q=80",
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800&q=80"
    ],
    featured: true
  },
  {
    id: 3,
    name: "Garden Loft",
    description: "Sunlit and open, the Garden Loft brings the outside in. Floor-to-ceiling glass, natural textiles, and direct garden access make this our most beloved retreat.",
    price: 72000,
    currency: "₦",
    features: ["King Bed", "Garden Access", "Floor-to-Ceiling Glass", "Kitchenette", "Free Wi-Fi", "Yoga Mat"],
    images: [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&q=80",
      "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=800&q=80",
      "https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800&q=80"
    ],
    featured: true
  },
  {
    id: 4,
    name: "The Penthouse",
    description: "An entire floor of sky, silence, and curated art. The Penthouse is Lumière at its most expansive — two bedrooms, a private dining room, and a rooftop terrace.",
    price: 250000,
    currency: "₦",
    features: ["2 Bedrooms", "Rooftop Terrace", "Private Dining", "Butler Service", "Panoramic View", "Jacuzzi"],
    images: [
      "https://images.unsplash.com/photo-1591088398332-8a7791972843?w=800&q=80",
      "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&q=80",
      "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80"
    ],
    featured: false
  },
  {
    id: 5,
    name: "Classic Room",
    description: "Refined and complete. The Classic Room delivers everything you need, beautifully — a comfortable queen bed, thoughtful lighting, and a pristine en-suite bathroom.",
    price: 38000,
    currency: "₦",
    features: ["Queen Bed", "En-Suite Bath", "Work Desk", "Smart TV", "Free Wi-Fi", "Daily Housekeeping"],
    images: [
      "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800&q=80",
      "https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800&q=80"
    ],
    featured: false
  }
];

const MENU = [
  {
    category: "Breakfast",
    items: [
      { id: 101, name: "Avocado Toast", desc: "Sourdough, smashed avocado, poached egg, chilli flakes", price: 4500, image: "https://images.unsplash.com/photo-1541519227354-08fa5d50c820?w=400&q=80" },
      { id: 102, name: "Akara & Ogi", desc: "Traditional bean cakes with warm pap and honey", price: 3200, image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=400&q=80" },
      { id: 103, name: "Continental Spread", desc: "Croissant, fruit bowl, yoghurt, assorted cold cuts", price: 6800, image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&q=80" },
      { id: 104, name: "French Toast", desc: "Brioche, maple syrup, fresh berries, crème fraîche", price: 5200, image: "" }
    ]
  },
  {
    category: "All Day Dining",
    items: [
      { id: 201, name: "Jollof Rice & Grilled Chicken", desc: "Smoky party-style jollof with seasoned grilled chicken and coleslaw", price: 7500, image: "https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?w=400&q=80" },
      { id: 202, name: "Pan-seared Salmon", desc: "Lemon butter sauce, wilted greens, herbed couscous", price: 12500, image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&q=80" },
      { id: 203, name: "Truffle Pasta", desc: "Tagliatelle, black truffle, parmesan, fresh herbs", price: 9800, image: "https://images.unsplash.com/photo-1555949258-eb67b1ef0ceb?w=400&q=80" },
      { id: 204, name: "Pepper Soup", desc: "Goat meat or catfish, aromatic spices, garden egg", price: 5500, image: "" }
    ]
  },
  {
    category: "Small Plates",
    items: [
      { id: 301, name: "Suya Skewers", desc: "Spiced beef skewers, sliced onion, tomato, groundnut crust", price: 4200, image: "https://images.unsplash.com/photo-1529042410759-befb1204b468?w=400&q=80" },
      { id: 302, name: "Burrata", desc: "Heirloom tomato, basil oil, sea salt, sourdough crisps", price: 6500, image: "https://images.unsplash.com/photo-1555243896-c709bfa0b564?w=400&q=80" },
      { id: 303, name: "Plantain Chips & Dip", desc: "Thinly sliced fried plantain, avocado dip", price: 2800, image: "" }
    ]
  },
  {
    category: "Drinks",
    items: [
      { id: 401, name: "Zobo Spritz", desc: "Hibiscus tea, ginger, citrus, sparkling water", price: 2500, image: "" },
      { id: 402, name: "Freshly Pressed Juice", desc: "Orange, watermelon, pineapple or cucumber-mint", price: 2200, image: "" },
      { id: 403, name: "Specialty Coffee", desc: "Espresso, flat white, cold brew or pourover", price: 2000, image: "" },
      { id: 404, name: "Chapman", desc: "Classic Nigerian cocktail with Fanta, Sprite, grenadine, cucumber", price: 2800, image: "" }
    ]
  },
  {
    category: "Desserts",
    items: [
      { id: 501, name: "Chocolate Lava Cake", desc: "Warm dark chocolate, vanilla bean ice cream", price: 4500, image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&q=80" },
      { id: 502, name: "Panna Cotta", desc: "Vanilla, passion fruit coulis, coconut crumble", price: 3800, image: "" }
    ]
  }
];
